define(["qlik", "jquery", "css!./open-book.css"], function (qlik, $) {
  "use strict";

  /* ---------- Idiomas ---------- */
  var I18N = {
    en: {
      pages: "Pages", addPage: "Add page", page: "Page", pageTitle: "Page title", master: "Master visualization",
      none: "(none)", appearance: "Appearance", borderColor: "Border color", bgColor: "Background color",
      paperColor: "Page color", borderWidth: "Border width", radius: "Corner radius", shadow: "Shadow",
      shadowOn: "Show shadow", shadowIntensity: "Shadow intensity", shadowSize: "Shadow size",
      numbering: "Page numbering", numOn: "Number pages", numStart: "First page number",
      numPos: "Number position", posOuter: "Outer corner", posCenter: "Centered", showTitle: "Show page titles",
      animation: "Animation", duration: "Page turn duration (ms)", noPages: "Add pages in the properties panel.",
      errorLoad: "Could not load object", prev: "Previous", next: "Next",
      fontFamily: "Font family", fontSize: "Font size", fontColor: "Font color", titles: "Page titles", pageShade: "Page shading", titleAlign: "Title alignment", alignLeft: "Left", alignCenter: "Center", alignRight: "Right", usedOn: "in use on page", dupMsg: "This visualization is already used on page"
    },
    es: {
      pages: "Páginas", addPage: "Añadir página", page: "Página", pageTitle: "Título de la página", master: "Visualización maestra",
      none: "(ninguna)", appearance: "Apariencia", borderColor: "Color del borde", bgColor: "Color de fondo",
      paperColor: "Color de las páginas", borderWidth: "Grosor del borde", radius: "Radio de las esquinas", shadow: "Sombra",
      shadowOn: "Mostrar sombra", shadowIntensity: "Intensidad de la sombra", shadowSize: "Tamaño de la sombra",
      numbering: "Numeración de páginas", numOn: "Numerar páginas", numStart: "Número de la primera página",
      numPos: "Posición del número", posOuter: "Esquina exterior", posCenter: "Centrado", showTitle: "Mostrar títulos de página",
      animation: "Animación", duration: "Duración del giro (ms)", noPages: "Añade páginas en el panel de propiedades.",
      errorLoad: "No se pudo cargar el objeto", prev: "Anterior", next: "Siguiente",
      fontFamily: "Tipo de fuente", fontSize: "Tamaño de fuente", fontColor: "Color de la fuente", titles: "Títulos de página", pageShade: "Sombreado de las páginas", titleAlign: "Alineación del título", alignLeft: "Izquierda", alignCenter: "Centrado", alignRight: "Derecha", usedOn: "en uso en la página", dupMsg: "Esta visualización ya se usa en la página"
    },
    it: {
      pages: "Pagine", addPage: "Aggiungi pagina", page: "Pagina", pageTitle: "Titolo della pagina", master: "Visualizzazione master",
      none: "(nessuna)", appearance: "Aspetto", borderColor: "Colore del bordo", bgColor: "Colore di sfondo",
      paperColor: "Colore delle pagine", borderWidth: "Spessore del bordo", radius: "Raggio degli angoli", shadow: "Ombra",
      shadowOn: "Mostra ombra", shadowIntensity: "Intensità dell'ombra", shadowSize: "Dimensione dell'ombra",
      numbering: "Numerazione delle pagine", numOn: "Numera le pagine", numStart: "Numero della prima pagina",
      numPos: "Posizione del numero", posOuter: "Angolo esterno", posCenter: "Centrato", showTitle: "Mostra i titoli delle pagine",
      animation: "Animazione", duration: "Durata del giro di pagina (ms)", noPages: "Aggiungi pagine nel pannello delle proprietà.",
      errorLoad: "Impossibile caricare l'oggetto", prev: "Precedente", next: "Successivo",
      fontFamily: "Tipo di carattere", fontSize: "Dimensione del carattere", fontColor: "Colore del carattere", titles: "Titoli delle pagine",
      pageShade: "Ombreggiatura delle pagine", titleAlign: "Allineamento del titolo", alignLeft: "Sinistra", alignCenter: "Centrato", alignRight: "Destra",
      usedOn: "in uso nella pagina", dupMsg: "Questa visualizzazione è già utilizzata nella pagina"
    },
    pt: {
      pages: "Páginas", addPage: "Adicionar página", page: "Página", pageTitle: "Título da página", master: "Visualização mestre",
      none: "(nenhuma)", appearance: "Aparência", borderColor: "Cor da borda", bgColor: "Cor de fundo",
      paperColor: "Cor das páginas", borderWidth: "Espessura da borda", radius: "Raio dos cantos", shadow: "Sombra",
      shadowOn: "Mostrar sombra", shadowIntensity: "Intensidade da sombra", shadowSize: "Tamanho da sombra",
      numbering: "Numeração das páginas", numOn: "Numerar páginas", numStart: "Número da primeira página",
      numPos: "Posição do número", posOuter: "Canto externo", posCenter: "Centrado", showTitle: "Mostrar títulos das páginas",
      animation: "Animação", duration: "Duração da virada de página (ms)", noPages: "Adicione páginas no painel de propriedades.",
      errorLoad: "Não foi possível carregar o objeto", prev: "Anterior", next: "Seguinte",
      fontFamily: "Tipo de letra", fontSize: "Tamanho da letra", fontColor: "Cor da letra", titles: "Títulos das páginas",
      pageShade: "Sombreamento das páginas", titleAlign: "Alinhamento do título", alignLeft: "Esquerda", alignCenter: "Centrado", alignRight: "Direita",
      usedOn: "em uso na página", dupMsg: "Esta visualização já é utilizada na página"
    },
    fr: {
      pages: "Pages", addPage: "Ajouter une page", page: "Page", pageTitle: "Titre de la page", master: "Visualisation principale",
      none: "(aucune)", appearance: "Apparence", borderColor: "Couleur de la bordure", bgColor: "Couleur d'arrière-plan",
      paperColor: "Couleur des pages", borderWidth: "Épaisseur de la bordure", radius: "Rayon des coins", shadow: "Ombre",
      shadowOn: "Afficher l'ombre", shadowIntensity: "Intensité de l'ombre", shadowSize: "Taille de l'ombre",
      numbering: "Numérotation des pages", numOn: "Numéroter les pages", numStart: "Numéro de la première page",
      numPos: "Position du numéro", posOuter: "Coin extérieur", posCenter: "Centré", showTitle: "Afficher les titres de page",
      animation: "Animation", duration: "Durée du tournage de page (ms)", noPages: "Ajoutez des pages dans le panneau des propriétés.",
      errorLoad: "Impossible de charger l'objet", prev: "Précédent", next: "Suivant",
      fontFamily: "Police", fontSize: "Taille de police", fontColor: "Couleur de police", titles: "Titres de page", pageShade: "Ombrage des pages", titleAlign: "Alignement du titre", alignLeft: "Gauche", alignCenter: "Centré", alignRight: "Droite", usedOn: "utilisée à la page", dupMsg: "Cette visualisation est déjà utilisée à la page"
    },
    de: {
      pages: "Seiten", addPage: "Seite hinzufügen", page: "Seite", pageTitle: "Seitentitel", master: "Hauptvisualisierung",
      none: "(keine)", appearance: "Darstellung", borderColor: "Rahmenfarbe", bgColor: "Hintergrundfarbe",
      paperColor: "Seitenfarbe", borderWidth: "Rahmenbreite", radius: "Eckenradius", shadow: "Schatten",
      shadowOn: "Schatten anzeigen", shadowIntensity: "Schattenintensität", shadowSize: "Schattengröße",
      numbering: "Seitennummerierung", numOn: "Seiten nummerieren", numStart: "Nummer der ersten Seite",
      numPos: "Position der Nummer", posOuter: "Äußere Ecke", posCenter: "Zentriert", showTitle: "Seitentitel anzeigen",
      animation: "Animation", duration: "Dauer des Umblätterns (ms)", noPages: "Fügen Sie Seiten im Eigenschaftenbereich hinzu.",
      errorLoad: "Objekt konnte nicht geladen werden", prev: "Zurück", next: "Weiter",
      fontFamily: "Schriftart", fontSize: "Schriftgröße", fontColor: "Schriftfarbe", titles: "Seitentitel", pageShade: "Seitenschattierung", titleAlign: "Titelausrichtung", alignLeft: "Links", alignCenter: "Zentriert", alignRight: "Rechts", usedOn: "verwendet auf Seite", dupMsg: "Diese Visualisierung wird bereits verwendet auf Seite"
    }
  };

  /* Fuentes de los objetos Qlik (lista editable). Valor = pila CSS completa */
  var FONT_PICKER_PREVIEW = true;   // false = desplegable nativo sin vista previa
  var FONTS = [
    ["QlikView Sans", "'QlikView Sans', sans-serif"],
    ["Abril Fatface", "'Abril Fatface', serif"],
    ["Bangers", "Bangers, fantasy"],
    ["Bebas Neue", "'Bebas Neue', sans-serif"],
    ["EB Garamond", "'EB Garamond', serif"],
    ["Fredoka One", "'Fredoka One', fantasy"],
    ["Graduate", "Graduate, fantasy"],
    ["Gravitas One", "'Gravitas One', serif"],
    ["Indie Flower", "'Indie Flower', fantasy"],
    ["Inter", "Inter, sans-serif"],
    ["Lobster", "Lobster, fantasy"],
    ["Montserrat", "Montserrat, sans-serif"],
    ["Nixio One", "'Nixio One', 'Nixie One', sans-serif"],
    ["Noto Sans", "'Noto Sans', sans-serif"],
    ["Open Sans", "'Open Sans', sans-serif"],
    ["PT Serif", "'PT Serif', serif"],
    ["Pacifico", "Pacifico, cursive"],
    ["Permanent Marker", "'Permanent Marker', fantasy"],
    ["Raleway", "Raleway, sans-serif"],
    ["Rammetto One", "'Rammetto One', fantasy"],
    ["Roboto", "Roboto, sans-serif"],
    ["Source Sans Pro", "'Source Sans Pro', sans-serif"],
    ["Titan One", "'Titan One', fantasy"],
    ["Yanone Kaffeesatz", "'Yanone Kaffeesatz', sans-serif"]
  ];
  function fontOptions() {
    return FONTS.map(function (f) { return { value: f[1], label: f[0] }; });
  }
  function fontLabel(value) {
    for (var k = 0; k < FONTS.length; k++) if (FONTS[k][1] === value) return FONTS[k][0];
    return String(value || FONTS[0][1]).split(",")[0].replace(/['"]/g, "");
  }

  // Selector de fuente con vista previa: cada opción se dibuja con su propia tipografía
  function fontPicker(key, showFn) {
    return {
      ref: "props." + key, type: "string", defaultValue: FONTS[0][1], show: showFn,
      component: {
        template:
          '<div class="ob-fp">' +
          '<div class="ob-fp-label">{{label()}}</div>' +
          '<div class="ob-fp-sel" ng-click="toggle()" ng-style="{\'font-family\': current()}">{{currentLabel()}}<span class="ob-fp-caret">&#9662;</span></div>' +
          '<ul class="ob-fp-list" ng-if="open">' +
          '<li ng-repeat="f in fonts" ng-class="{sel: f.value === current()}" ng-style="{\'font-family\': f.value}" ng-click="pick(f)">{{f.label}}</li>' +
          '</ul></div>',
        controller: ["$scope", function ($scope) {
          $scope.open = false;
          $scope.fonts = fontOptions();
          $scope.label = function () { return t("fontFamily"); };
          $scope.current = function () { return ($scope.data && $scope.data.props && $scope.data.props[key]) || FONTS[0][1]; };
          $scope.currentLabel = function () { return fontLabel($scope.current()); };
          $scope.toggle = function () { $scope.open = !$scope.open; };
          $scope.pick = function (f) {
            $scope.data.props = $scope.data.props || {};
            $scope.data.props[key] = f.value;
            $scope.open = false;
            $scope.$emit("saveProperties");
          };
        }]
      }
    };
  }

  var MASTER_PICKER_CUSTOM = true;   // false = desplegable nativo (sin deshabilitar las usadas)

  // Selector de visualización maestra: las ya usadas en otras páginas aparecen deshabilitadas
  function masterPicker() {
    return {
      ref: "masterId", type: "string", defaultValue: "",
      component: {
        template:
          '<div class="ob-fp">' +
          '<div class="ob-fp-label">{{label()}}</div>' +
          '<div class="ob-fp-sel" ng-click="toggle()">{{currentLabel()}}<span class="ob-fp-caret">&#9662;</span></div>' +
          '<ul class="ob-fp-list" ng-if="open">' +
          '<li ng-repeat="m in items()" ng-class="{sel: m.value === current(), dis: m.usedOn}" ng-click="pick(m)">' +
          '{{m.label}}<span ng-if="m.usedOn" class="ob-fp-used"> — {{usedText()}} {{m.usedOn}}</span></li>' +
          '</ul></div>',
        controller: ["$scope", function ($scope) {
          $scope.open = false;
          $scope.list = [{ value: "", label: t("none") }];
          masterObjectList().then(function (l) {
            $scope.$evalAsync(function () { $scope.list = l; });
          });
          $scope.label = function () { return t("master"); };
          $scope.usedText = function () { return t("usedOn"); };
          $scope.current = function () { return ($scope.data && $scope.data.masterId) || ""; };
          function allPages() {
            var a = $scope.args && $scope.args.properties;
            return (a && a.pages) || [];
          }
          function usedMap() {
            var pages = allPages(), self = pages.indexOf($scope.data), cur = $scope.current(), skipped = false, map = {};
            for (var i = 0; i < pages.length; i++) {
              var v = pages[i] && pages[i].masterId;
              if (!v) continue;
              if (i === self) continue;
              if (self === -1 && v === cur && !skipped) { skipped = true; continue; }
              if (!map[v]) map[v] = i + 1;
            }
            return map;
          }
          $scope.items = function () {
            var used = usedMap(), cur = $scope.current();
            return $scope.list.map(function (m) {
              return { value: m.value, label: m.label, usedOn: (m.value && m.value !== cur && used[m.value]) ? used[m.value] : null };
            });
          };
          $scope.currentLabel = function () {
            var cur = $scope.current();
            for (var k = 0; k < $scope.list.length; k++) if ($scope.list[k].value === cur) return $scope.list[k].label;
            return cur || t("none");
          };
          $scope.toggle = function () { $scope.open = !$scope.open; };
          $scope.pick = function (m) {
            if (m.usedOn) return;
            $scope.data.masterId = m.value;
            $scope.open = false;
            $scope.$emit("saveProperties");
          };
        }]
      }
    };
  }

  function fontItems(prefix, defSize, defColor, showFn, maxSize) {
    var o = {};
    o[prefix + "Family"] = FONT_PICKER_PREVIEW
      ? fontPicker(prefix + "Family", showFn)
      : {
        ref: "props." + prefix + "Family", type: "string", component: "dropdown", defaultValue: FONTS[0][1],
        label: function () { return t("fontFamily"); }, options: fontOptions, show: showFn
      };
    o[prefix + "Size"] = {
      ref: "props." + prefix + "Size", type: "number", component: "slider", defaultValue: defSize,
      label: function () { return t("fontSize"); }, min: 8, max: maxSize || 48, step: 1, show: showFn
    };
    o[prefix + "Color"] = {
      ref: "props." + prefix + "Color", type: "object", component: "color-picker", dualOutput: true,
      label: function () { return t("fontColor"); }, defaultValue: { index: -1, color: defColor }, show: showFn
    };
    return o;
  }

  function lang() {
    var l = (document.documentElement.lang || navigator.language || "en").toLowerCase().split("-")[0];
    return I18N[l] ? l : "en";
  }
  function t(k) {
    var d = I18N[lang()] || I18N.en;
    return d[k] || I18N.en[k] || k;
  }

  /* ---------- Utilidades ---------- */
  function col(v, d) {
    if (!v) return d;
    if (typeof v === "string") return v;
    return v.color || d;
  }
  function isDark(c) {
    try {
      var cx = document.createElement("canvas").getContext("2d");
      cx.fillStyle = "#ffffff";
      cx.fillStyle = c;
      var v = cx.fillStyle, r, g, b;
      if (v.charAt(0) === "#") {
        r = parseInt(v.substr(1, 2), 16); g = parseInt(v.substr(3, 2), 16); b = parseInt(v.substr(5, 2), 16);
      } else {
        var m = v.match(/[\d.]+/g); r = +m[0]; g = +m[1]; b = +m[2];
      }
      return (0.299 * r + 0.587 * g + 0.114 * b) < 140;
    } catch (e) { return true; }
  }
  function num(v, d) { v = Number(v); return isNaN(v) ? d : v; }

  function masterObjectList() {
    var app = qlik.currApp();
    return new Promise(function (resolve) {
      app.getAppObjectList("masterobject", function (reply) {
        var items = [{ value: "", label: t("none") }];
        try {
          reply.qAppObjectList.qItems.forEach(function (it) {
            items.push({
              value: it.qInfo.qId,
              label: (it.qMeta && it.qMeta.title ? it.qMeta.title : "(?)")
            });
          });
        } catch (e) { /* lista vacía */ }
        resolve(items);
      });
    });
  }

  /* ---------- Construcción del libro ---------- */
  /* Página 1 = izquierda del primer pliego.
     Pliego s: izquierda = P(2s), derecha = P(2s+1).
     Mitad izquierda fija: P0. Hoja j: anverso P(2j+1), reverso P(2j+2).
     Mitad derecha fija: P(2L+1) (puede quedar en blanco). */
  function faceHtml(cls, blank) {
    return '<div class="ob-face ' + cls + (blank ? " ob-blank" : "") + '">' +
      '<div class="ob-head"></div><div class="ob-body"><div class="ob-host"></div></div>' +
      '<div class="ob-num"></div><div class="ob-shade"></div></div>';
  }

  function build($el, pages, app, prevSpread) {
    var n = pages.length;
    var L = n > 0 ? Math.ceil(n / 2) - 1 : 0;
    var st = { n: n, L: L, spread: Math.max(0, Math.min(prevSpread || 0, L)), pages: [], leaves: [], timers: [], turnZ: 0, app: app, dur: 700 };

    var $root = $('<div class="ob-root" tabindex="0"></div>');
    var $book = $('<div class="ob-book"></div>');
    var $stage = $('<div class="ob-stage"></div>');
    $root.append($book);
    $book.append($stage);
    st.$root = $root; st.$book = $book;

    if (n === 0) {
      $stage.append('<div class="ob-empty"></div>');
      $stage.find(".ob-empty").text(t("noPages"));
      $el.empty().append($root);
      return st;
    }

    // Una visualización repetida en varias páginas: la primera usa el objeto original, las demás una copia de sesión
    var seen = {}, dups = [];
    for (var q = 0; q < n; q++) {
      var qid = pages[q].masterId || "";
      dups[q] = (qid && seen[qid]) ? seen[qid] : 0;
      if (qid && !seen[qid]) seen[qid] = q + 1;
    }

    function reg(i, $face) {
      if (i >= n) return;
      st.pages[i] = {
        id: pages[i].masterId || "", dupOf: dups[i], host: $face.find(".ob-host")[0],
        $head: $face.find(".ob-head"), $num: $face.find(".ob-num"), state: null
      };
    }

    $stage.append('<div class="ob-under l"></div><div class="ob-under r"></div>');
    var $fl = $(faceHtml("ob-static ob-side-l", false));
    $stage.find(".ob-under.l").append($fl);
    reg(0, $fl);
    st.$sl = $fl;
    var rIdx = 2 * L + 1;
    var $fr = $(faceHtml("ob-static ob-side-r", rIdx >= n));
    $stage.find(".ob-under.r").append($fr);
    reg(rIdx, $fr);
    st.$sr = $fr;

    var $leaves = $('<div class="ob-leaves"></div>');
    $stage.append($leaves);
    for (var j = 0; j < L; j++) {
      var iF = 2 * j + 1, iB = 2 * j + 2;
      var $leaf = $('<div class="ob-leaf"></div>');
      var $f = $(faceHtml("ob-front ob-side-r", false));
      var $b = $(faceHtml("ob-back ob-side-l", false));
      $leaf.append($f).append($b);
      $leaves.append($leaf);
      st.leaves.push($leaf);
      reg(iF, $f);
      reg(iB, $b);
    }

    $stage.append('<div class="ob-spine"></div>');

    var $prev = $('<button class="ob-nav prev" type="button">&#10094;</button>').attr("title", t("prev"));
    var $next = $('<button class="ob-nav next" type="button">&#10095;</button>').attr("title", t("next"));
    $book.append($prev).append($next);
    st.$prev = $prev; st.$next = $next;

    $prev.on("click", function (e) { e.stopPropagation(); go(st, -1); });
    $next.on("click", function (e) { e.stopPropagation(); go(st, 1); });
    $root.on("keydown", function (e) {
      if (e.which === 37) { go(st, -1); e.preventDefault(); }
      if (e.which === 39) { go(st, 1); e.preventDefault(); }
    });

    $el.empty().append($root);

    // Estado inicial sin animación
    $root.addClass("ob-notrans");
    for (var k = 0; k < L; k++) {
      st.leaves[k].toggleClass("flipped", k < st.spread);
      setFinalZ(st, k);
    }
    void $root[0].offsetWidth;
    setTimeout(function () { $root.removeClass("ob-notrans"); }, 30);

    updateNav(st);
    updateStatic(st);
    sync(st);
    return st;
  }

  function updateStatic(st) {
    // Las caras fijas solo se muestran cuando están a la vista (evita que objetos Qlik "traspasen" las hojas)
    if (!st.$sl) return;
    st.$sl.toggleClass("ob-hidden", st.spread > 0);
    st.$sr.toggleClass("ob-hidden", st.spread < st.L);
  }

  function setFinalZ(st, j) {
    var flipped = j < st.spread;
    st.leaves[j].css("z-index", flipped ? (j + 1) : (st.L - j + 1));
  }

  function go(st, dir) {
    var j;
    if (dir > 0) {
      if (st.spread >= st.L) return;
      j = st.spread;
      st.spread++;
    } else {
      if (st.spread <= 0) return;
      st.spread--;
      j = st.spread;
    }
    var $leaf = st.leaves[j];
    if (st.$sl) { st.$sl.removeClass("ob-hidden"); st.$sr.removeClass("ob-hidden"); }
    clearTimeout(st.staticTimer);
    st.staticTimer = setTimeout(function () { updateStatic(st); }, st.dur + 80);
    clearTimeout(st.timers[j]);
    st.turnZ = (st.turnZ + 1) % 50000;
    $leaf.addClass("turning").css("z-index", 200 + st.turnZ);
    $leaf.toggleClass("flipped", j < st.spread);
    st.timers[j] = setTimeout(function () {
      $leaf.removeClass("turning");
      setFinalZ(st, j);
    }, st.dur + 60);
    updateNav(st);
    sync(st);
  }

  function updateNav(st) {
    st.$prev.prop("disabled", st.spread <= 0);
    st.$next.prop("disabled", st.spread >= st.L);
  }

  /* ---------- Carga perezosa de objetos ---------- */
  function sync(st) {
    // Visibles: 2s y 2s+1. Precarga: el pliego anterior y el siguiente
    var lo = 2 * st.spread - 2, hi = 2 * st.spread + 3;
    for (var i = 0; i < st.n; i++) {
      if (i >= lo && i <= hi) loadPage(st, i); else releasePage(st, i);
    }
  }

  function disposeResult(st, r) {
    try { if (r.obj && r.obj.close) r.obj.close(); } catch (e) {}
  }

  function loadPage(st, i) {
    var p = st.pages[i];
    if (!p || p.state || !p.id) return;
    if (p.dupOf) {
      // Visualización ya usada en una página anterior: no se carga (Qlik no admite el mismo objeto en dos sitios)
      p.state = "dup";
      $(p.host).empty().append($('<div class="ob-err"></div>').text(t("dupMsg") + " " + p.dupOf));
      return;
    }
    p.state = "loading";
    st.app.getObject(p.host, p.id).then(function (obj) {
      if (p.state !== "loading") { disposeResult(st, { obj: obj }); return; }
      p.obj = obj; p.state = "loaded";
    }).catch(function (err) {
      p.state = "error";
      var msg = (err && (err.message || err.code)) || "";
      $(p.host).empty().append($('<div class="ob-err"></div>').text(t("errorLoad") + " " + p.id + (msg ? ": " + msg : "")));
    });
  }

  function releasePage(st, i) {
    var p = st.pages[i];
    if (!p || !p.state) return;
    if (p.state === "loaded") disposeResult(st, { obj: p.obj });
    p.obj = null;
    p.state = null;
    $(p.host).empty();
  }

  function destroy(st) {
    if (!st) return;
    (st.timers || []).forEach(function (h) { clearTimeout(h); });
    clearTimeout(st.staticTimer);
    for (var i = 0; i < st.n; i++) releasePage(st, i);
  }

  /* ---------- Estilos y textos ---------- */
  function applyStyle(st, props) {
    var bg = col(props.backgroundColor, "#6d4c41");
    var border = col(props.borderColor, "#4e342e");
    var paper = col(props.paperColor, "#fdfbf5");
    var bw = num(props.borderWidth, 6);
    var radius = num(props.borderRadius, 8);
    var on = props.shadowOn !== false;
    var inten = num(props.shadowIntensity, 50);
    var size = num(props.shadowSize, 25);
    var dur = num(props.duration, 700);
    st.dur = dur;

    var shadow = on
      ? "0 " + Math.round(size / 3) + "px " + size + "px " + Math.round(size / 4) + "px rgba(0,0,0," + (inten / 100 * 0.7).toFixed(2) + ")"
      : "none";
    var pad = on ? Math.min(Math.round(size * 1.3) + 6, 80) : 6;
    var arrow = isDark(bg) ? "#ffffff" : "#222222";

    var r = st.$root[0].style;
    r.setProperty("--ob-bg", bg);
    r.setProperty("--ob-border", border);
    r.setProperty("--ob-paper", paper);
    r.setProperty("--ob-bw", bw + "px");
    r.setProperty("--ob-radius", radius + "px");
    r.setProperty("--ob-pr", radius + "px");
    r.setProperty("--ob-shadow", shadow);
    r.setProperty("--ob-pad", pad + "px");
    r.setProperty("--ob-dur", dur + "ms");
    r.setProperty("--ob-arrow", arrow);
    // Sombra de las páginas: solo hacia el exterior, nunca hacia el lomo
    var k = num(props.pageShade, 60) / 100;
    if (k > 0) {
      var a1 = (0.32 * k).toFixed(3), a2 = (0.26 * k).toFixed(3);
      r.setProperty("--ob-ps-r", "2px 3px 5px rgba(0,0,0," + a1 + "), 5px 8px 14px -3px rgba(0,0,0," + a2 + ")");
      r.setProperty("--ob-ps-l", "-2px 3px 5px rgba(0,0,0," + a1 + "), -5px 8px 14px -3px rgba(0,0,0," + a2 + ")");
    } else {
      r.setProperty("--ob-ps-r", "none");
      r.setProperty("--ob-ps-l", "none");
    }
    r.setProperty("--ob-title-ta", props.titleAlign || "left");

    // Fuentes: solo se aplican si la opción correspondiente está activada
    function font(prefix, cssPrefix, active, defSize, defColor) {
      if (active) {
        r.setProperty("--ob-" + cssPrefix + "-ff", props[prefix + "Family"] || FONTS[0][1]);
        r.setProperty("--ob-" + cssPrefix + "-fs", num(props[prefix + "Size"], defSize) + "px");
        r.setProperty("--ob-" + cssPrefix + "-fc", col(props[prefix + "Color"], defColor));
      } else {
        r.removeProperty("--ob-" + cssPrefix + "-ff");
        r.removeProperty("--ob-" + cssPrefix + "-fs");
        r.removeProperty("--ob-" + cssPrefix + "-fc");
      }
    }
    font("titleFont", "title", !!props.showTitle, 14, "#333333");
    font("numFont", "num", !!props.numbering, 12, "#555555");

    st.$root.toggleClass("ob-numbered", !!props.numbering);
    st.$root.toggleClass("ob-title", !!props.showTitle);
    st.$root.removeClass("ob-pos-outer ob-pos-center")
      .addClass(props.numPosition === "center" ? "ob-pos-center" : "ob-pos-outer");
  }

  function updateTexts(st, pages, props) {
    var start = num(props.numStart, 1);
    for (var i = 0; i < st.n; i++) {
      var p = st.pages[i];
      if (!p) continue;
      p.$head.text(pages[i].title || "");
      p.$num.text(start + i);
    }
  }

  /* ---------- Extensión ---------- */
  return {
    initialProperties: {
      pages: [
        { title: "", masterId: "" },
        { title: "", masterId: "" }
      ],
      props: {
        backgroundColor: { index: -1, color: "#6d4c41" },
        borderColor: { index: -1, color: "#4e342e" },
        paperColor: { index: -1, color: "#fdfbf5" },
        borderWidth: 6, borderRadius: 8,
        shadowOn: true, shadowIntensity: 50, shadowSize: 25,
        numbering: true, numStart: 1, numPosition: "outer", showTitle: false,
        titleAlign: "left", pageShade: 60,
        titleFontFamily: FONTS[0][1], titleFontSize: 14, titleFontColor: { index: -1, color: "#333333" },
        numFontFamily: FONTS[0][1], numFontSize: 12, numFontColor: { index: -1, color: "#555555" },
        duration: 700
      }
    },

    definition: {
      type: "items",
      component: "accordion",
      items: {
        pagesSection: {
          type: "items",
          label: function () { return t("pages"); },
          items: {
            pages: {
              type: "array",
              ref: "pages",
              label: function () { return t("pages"); },
              itemTitleRef: function (item, i) {
                return item && item.title ? item.title : (t("page") + " " + (i + 1));
              },
              allowAdd: true,
              allowRemove: true,
              allowMove: true,
              addTranslation: t("addPage"),
              items: {
                title: {
                  type: "string", ref: "title", defaultValue: "",
                  label: function () { return t("pageTitle"); }, expression: "optional"
                },
                masterId: MASTER_PICKER_CUSTOM ? masterPicker() : {
                  type: "string", ref: "masterId", component: "dropdown", defaultValue: "",
                  label: function () { return t("master"); },
                  options: masterObjectList
                }
              }
            }
          }
        },
        appearance: {
          type: "items",
          label: function () { return t("appearance"); },
          items: {
            backgroundColor: {
              ref: "props.backgroundColor", type: "object", component: "color-picker", dualOutput: true,
              label: function () { return t("bgColor"); }, defaultValue: { index: -1, color: "#6d4c41" }
            },
            borderColor: {
              ref: "props.borderColor", type: "object", component: "color-picker", dualOutput: true,
              label: function () { return t("borderColor"); }, defaultValue: { index: -1, color: "#4e342e" }
            },
            paperColor: {
              ref: "props.paperColor", type: "object", component: "color-picker", dualOutput: true,
              label: function () { return t("paperColor"); }, defaultValue: { index: -1, color: "#fdfbf5" }
            },
            borderWidth: {
              ref: "props.borderWidth", type: "number", component: "slider",
              label: function () { return t("borderWidth"); }, min: 0, max: 20, step: 1, defaultValue: 6
            },
            borderRadius: {
              ref: "props.borderRadius", type: "number", component: "slider",
              label: function () { return t("radius"); }, min: 0, max: 30, step: 1, defaultValue: 8
            },
            pageShade: {
              ref: "props.pageShade", type: "number", component: "slider",
              label: function () { return t("pageShade"); }, min: 0, max: 100, step: 5, defaultValue: 60
            }
          }
        },
        shadowSection: {
          type: "items",
          label: function () { return t("shadow"); },
          items: {
            shadowOn: {
              ref: "props.shadowOn", type: "boolean", defaultValue: true,
              label: function () { return t("shadowOn"); }
            },
            shadowIntensity: {
              ref: "props.shadowIntensity", type: "number", component: "slider",
              label: function () { return t("shadowIntensity"); }, min: 0, max: 100, step: 5, defaultValue: 50,
              show: function (d) { return !d.props || d.props.shadowOn !== false; }
            },
            shadowSize: {
              ref: "props.shadowSize", type: "number", component: "slider",
              label: function () { return t("shadowSize"); }, min: 0, max: 60, step: 1, defaultValue: 25,
              show: function (d) { return !d.props || d.props.shadowOn !== false; }
            }
          }
        },
        titlesSection: {
          type: "items",
          label: function () { return t("titles"); },
          items: $.extend({
            showTitle: {
              ref: "props.showTitle", type: "boolean", defaultValue: false,
              label: function () { return t("showTitle"); }
            },
            titleAlign: {
              ref: "props.titleAlign", type: "string", component: "dropdown", defaultValue: "left",
              label: function () { return t("titleAlign"); },
              options: function () {
                return [{ value: "left", label: t("alignLeft") }, { value: "center", label: t("alignCenter") }, { value: "right", label: t("alignRight") }];
              },
              show: function (d) { return !!(d.props && d.props.showTitle); }
            }
          }, fontItems("titleFont", 14, "#333333", function (d) { return !!(d.props && d.props.showTitle); }, 120))
        },
        numberingSection: {
          type: "items",
          label: function () { return t("numbering"); },
          items: $.extend({
            numbering: {
              ref: "props.numbering", type: "boolean", defaultValue: true,
              label: function () { return t("numOn"); }
            },
            numStart: {
              ref: "props.numStart", type: "number", defaultValue: 1,
              label: function () { return t("numStart"); },
              show: function (d) { return !!(d.props && d.props.numbering); }
            },
            numPosition: {
              ref: "props.numPosition", type: "string", component: "dropdown", defaultValue: "outer",
              label: function () { return t("numPos"); },
              options: function () {
                return [{ value: "outer", label: t("posOuter") }, { value: "center", label: t("posCenter") }];
              },
              show: function (d) { return !!(d.props && d.props.numbering); }
            }
          }, fontItems("numFont", 12, "#555555", function (d) { return !!(d.props && d.props.numbering); }))
        },
        animationSection: {
          type: "items",
          label: function () { return t("animation"); },
          items: {
            duration: {
              ref: "props.duration", type: "number", component: "slider",
              label: function () { return t("duration"); }, min: 200, max: 2000, step: 50, defaultValue: 700
            }
          }
        },
        settings: { uses: "settings" }
      }
    },

    support: { snapshot: false, export: false, exportData: false },

    paint: function ($element, layout) {
      var props = layout.props || {};
      var pages = layout.pages || [];
      var app = qlik.currApp(this);
      var st = $element.data("ob");
      var sig = pages.map(function (p) { return p.masterId || ""; }).join("|");

      if (!st || st.sig !== sig) {
        var prevSpread = st ? st.spread : 0;
        destroy(st);
        st = build($element, pages, app, prevSpread);
        st.sig = sig;
        $element.data("ob", st);
        this._ob = st;
      }
      st.app = app;
      applyStyle(st, props);
      updateTexts(st, pages, props);
      return qlik.Promise.resolve();
    },

    beforeDestroy: function () {
      if (this._ob) { destroy(this._ob); this._ob = null; }
    }
  };
});
